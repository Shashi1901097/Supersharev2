package com.supershare.app.core;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tests the real sender/receiver code over loopback TCP: integrity, names, resume, wrong keys, lockout,
 * insufficient storage, "already have", malformed input. Plain JDK so it runs anywhere (also as JUnit).
 */
public class CoreTests {
    static final long MB = 1L << 20;

    // ---------- tiny helpers ----------
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }

    static byte[] key(String code) throws Exception { return Keys.derive(code, 1000).authKey; }

    static final List<File> TMP = Collections.synchronizedList(new ArrayList<File>());

    static File tmp(String p) throws IOException {
        File d = Files.createTempDirectory(p).toFile();
        TMP.add(d);
        return d;
    }

    /** Deletes every temp directory the tests created. */
    public static void cleanup() {
        synchronized (TMP) { for (File d : TMP) deleteAll(d); TMP.clear(); }
    }

    static void deleteAll(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteAll(k);
        f.delete();
    }

    static File makeFile(File dir, String name, long size, long seed) throws IOException {
        File f = new File(dir, name);
        f.getParentFile().mkdirs();
        Random r = new Random(seed);
        byte[] b = new byte[1 << 16];
        try (OutputStream o = new BufferedOutputStream(new FileOutputStream(f), 1 << 16)) {
            long left = size;
            while (left > 0) { r.nextBytes(b); int n = (int) Math.min(b.length, left); o.write(b, 0, n); left -= n; }
        }
        return f;
    }

    static String sha(File f) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[1 << 16]; int n;
            while ((n = in.read(b)) > 0) d.update(b, 0, n);
        }
        return Base64.getEncoder().encodeToString(d.digest());
    }

    static final class FileSource implements Source {
        final File f; final String name;
        FileSource(File f, String name) { this.f = f; this.name = name; }
        FileSource(File f) { this(f, f.getName()); }
        public String id() { return Protocol.fileId(name, f.length(), 1L); }
        public String name() { return name; }
        public long size() { return f.length(); }
        public Opened open() throws IOException {
            final FileChannel ch = FileChannel.open(f.toPath(), StandardOpenOption.READ);
            return new Opened() { public FileChannel channel() { return ch; } public void close() throws IOException { ch.close(); } };
        }
    }

    static final class DirFactory implements TargetFactory {
        final File root;
        final AtomicLong free = new AtomicLong(Long.MAX_VALUE / 4);
        final Map<String, String> have = new java.util.concurrent.ConcurrentHashMap<>();
        volatile long slowMs = 0;
        DirFactory(File root) { this.root = root; new File(root, "part").mkdirs(); this.out = new File(root, "out"); this.out.mkdirs(); }
        public long freeBytes() { return free.get(); }
        public boolean alreadyHave(String id, long size) {
            String p = have.get(id);
            return p != null && new File(p).isFile() && new File(p).length() == size;
        }
        public BitSet peekBits(String id, long size) { return readBits(new File(root, "part/" + id + ".bits")); }
        public Target open(String id, String name, long size) throws IOException { return new DirTarget(this, id, name); }
        final File out;
        File out(String name) { return new File(root, "out/" + name); }
    }

    static BitSet readBits(File f) {
        try { return f.isFile() ? BitSet.valueOf(Files.readAllBytes(f.toPath())) : null; } catch (IOException e) { return null; }
    }

    static final class DirTarget implements Target {
        final DirFactory fac; final String id, name; final File bitsF; final FileChannel ch;
        DirTarget(DirFactory fac, String id, String name) throws IOException {
            this.fac = fac; this.id = id; this.name = name;
            bitsF = new File(fac.root, "part/" + id + ".bits");
            ch = FileChannel.open(new File(fac.root, "part/" + id + ".part").toPath(),
                    StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE);
        }
        public BitSet loadBits() { BitSet b = readBits(bitsF); return b == null ? new BitSet() : b; }
        public synchronized void saveBits(BitSet b) {
            try {                                    // write-then-rename so a reader never sees a half-written file
                File tmpF = new File(bitsF.getPath() + ".tmp");
                Files.write(tmpF.toPath(), b.toByteArray());
                Files.move(tmpF.toPath(), bitsF.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {}
        }
        public void write(long pos, ByteBuffer src) throws IOException {
            if (fac.slowMs > 0) { try { Thread.sleep(fac.slowMs); } catch (InterruptedException ignored) {} }
            while (src.hasRemaining()) pos += ch.write(src, pos);
        }
        public synchronized void finish() throws IOException {
            ch.close();
            File dst = fac.out(name);
            int i = 1;
            while (dst.exists()) { dst = fac.out(name + " (" + (i++) + ")"); }
            Files.move(new File(fac.root, "part/" + id + ".part").toPath(), dst.toPath());
            bitsF.delete();
            fac.have.put(id, dst.getPath());
        }
        public void close() { try { ch.close(); } catch (IOException ignored) {} }
    }

    static class Rec implements ReceiverEvents {
        final AtomicLong done = new AtomicLong(), total = new AtomicLong();
        final AtomicLong firstBatchDone = new AtomicLong(-1);
        final AtomicInteger started = new AtomicInteger(), finished = new AtomicInteger(), authFails = new AtomicInteger();
        final AtomicInteger blocked = new AtomicInteger(); final AtomicLong need = new AtomicLong();
        volatile java.util.function.LongConsumer hook;
        public void onBatch(long d, long t, int b, long n, String name) {
            firstBatchDone.compareAndSet(-1, d); blocked.set(b); need.set(n);
        }
        public void onProgress(long d, long t) {
            done.set(d); total.set(t);
            java.util.function.LongConsumer h = hook; if (h != null) h.accept(d);
        }
        public void onFileStart(String n) { started.incrementAndGet(); }
        public void onFileDone(String n) { finished.incrementAndGet(); }
        public void onAuthFailed(int n) { authFails.set(n); }
    }

    static Receiver rx(byte[] key, DirFactory f, Rec r) throws IOException {
        Receiver x = new Receiver(key, f, r);
        x.start(0, java.net.InetAddress.getLoopbackAddress());
        return x;
    }
    static int portOf(Receiver r) throws Exception {
        java.lang.reflect.Field f = Receiver.class.getDeclaredField("server"); f.setAccessible(true);
        return ((java.net.ServerSocket) f.get(r)).getLocalPort();
    }
    static Sender.Result send(int port, byte[] key, List<Source> files) throws IOException {
        return Sender.send("127.0.0.1", port, key, files, (d, t) -> {}, new AtomicBoolean(false));
    }
    static void expectFail(String what, ThrowingRunnable r) throws Exception {
        try { r.run(); } catch (IOException expected) { return; }
        throw new AssertionError("expected failure: " + what);
    }
    interface ThrowingRunnable { void run() throws Exception; }

    // ---------- tests ----------
    public static void testNames() {
        check(Names.sanitize("../../etc/passwd").equals("passwd"), "unix traversal");
        check(Names.sanitize("..\\..\\win\\system.ini").equals("system.ini"), "windows traversal");
        check(Names.sanitize("..").equals("file"), "dotdot");
        check(Names.sanitize(".").equals("file"), "dot");
        check(Names.sanitize("").equals("file"), "empty");
        check(Names.sanitize(null).equals("file"), "null");
        check(Names.sanitize("a\u0000b\nc.txt").equals("abc.txt"), "control chars");
        check(Names.sanitize("a:b*c?.txt").equals("a_b_c_.txt"), "bad chars");
        check(Names.sanitize("Holiday photo (1).jpg").equals("Holiday photo (1).jpg"), "normal name kept");
        check(Names.sanitize("video.mp4 ").equals("video.mp4"), "trailing space");
        StringBuilder sb = new StringBuilder(); for (int i = 0; i < 400; i++) sb.append('x');
        String longName = Names.sanitize(sb + ".mp4");
        check(longName.length() <= Protocol.MAX_NAME && longName.endsWith(".mp4"), "long name keeps extension");
    }

    public static void testKeys() throws Exception {
        String c = Keys.newCode();
        check(Keys.isValid(c) && c.length() == 10, "new code valid");
        check(!c.equals(Keys.newCode()), "codes differ");
        check(Keys.normalize("ab-cd ef gh jk 99").equals("ABCDEFGHJK"), "normalize");
        check(Keys.normalize("0O1I").isEmpty(), "ambiguous chars removed");
        check(!Keys.isValid("SHORT") && !Keys.isValid(null), "invalid rejected");
        check(Keys.pretty("ABCDEFGHJK").equals("ABCDE-FGHJK"), "pretty");
        Keys a = Keys.derive("ABCDEFGHJK", 1000), b = Keys.derive("ABCDEFGHJK", 1000), d = Keys.derive("ABCDEFGHJL", 1000);
        check(a.wifiName.equals(b.wifiName) && a.wifiPass.equals(b.wifiPass) && Arrays.equals(a.authKey, b.authKey), "deterministic");
        check(!a.wifiPass.equals(d.wifiPass) && !Arrays.equals(a.authKey, d.authKey), "different codes differ");
        check(a.wifiName.startsWith("DIRECT-SS-") && a.wifiName.length() <= 32, "ssid format");
        check(a.wifiPass.length() >= 8 && a.wifiPass.length() <= 63 && a.wifiPass.matches("[0-9a-f]+"), "wifi password format");
        check(a.authKey.length == 32, "auth key size");
        check(!a.wifiPass.contains("ABCDEFGHJK"), "password does not contain the code");
    }

    public static void testTransfer() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            List<Source> files = new ArrayList<>();
            files.add(new FileSource(makeFile(src, "empty.bin", 0, 1)));
            files.add(new FileSource(makeFile(src, "one.bin", 1, 2)));
            files.add(new FileSource(makeFile(src, "Holiday photo (final).jpg", 1_000_003, 3)));
            files.add(new FileSource(makeFile(src, "clip.mp4", 5 * MB + 17, 4)));
            files.add(new FileSource(makeFile(src, "big movie.mkv", 45 * MB + 5, 5)));   // > 32 MB: parallel streams
            Sender.Result res = send(portOf(r), key, files);
            check(res.complete && res.blockedIds.isEmpty(), "complete");
            for (Source s : files) {
                File out = fac.out(s.name());
                check(out.isFile(), "received " + s.name());
                check(out.length() == s.size(), "size " + s.name());
                check(sha(out).equals(sha(((FileSource) s).f)), "hash " + s.name());
            }
            check(rec.done.get() == rec.total.get(), "progress reaches 100%");
        } finally { r.stop(); }
    }

    public static void testResume() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        FileSource fs = new FileSource(makeFile(src, "huge.bin", 120 * MB, 9));
        fac.slowMs = 10;
        final Rec rec1 = new Rec();
        final Receiver r1 = rx(key, fac, rec1);
        final AtomicBoolean stopped = new AtomicBoolean(false);
        rec1.hook = d -> { if (d >= 50 * MB && !stopped.getAndSet(true)) new Thread(r1::stop).start(); };
        int p1 = portOf(r1);
        expectFail("interrupted transfer", () -> send(p1, key, Collections.singletonList((Source) fs)));
        r1.stop();
        check(stopped.get(), "receiver was stopped mid-transfer");
        BitSet saved = fac.peekBits(fs.id(), fs.size());
        check(saved != null && saved.cardinality() > 0, "progress was saved");
        check(saved.cardinality() < Protocol.chunksOf(fs.size()), "transfer was really partial");
        check(!fac.out("huge.bin").exists(), "no half file is published");

        fac.slowMs = 0;
        final Rec rec2 = new Rec();
        Receiver r2 = rx(key, fac, rec2);
        try {
            final long[] first = {-1};
            Sender.Result res = Sender.send("127.0.0.1", portOf(r2), key, Collections.singletonList((Source) fs),
                    (d, t) -> { if (first[0] < 0) first[0] = d; }, new AtomicBoolean(false));
            check(res.complete, "resume completes");
            check(first[0] > 0, "resume started from saved progress, not from zero (" + first[0] + ")");
            check(rec2.firstBatchDone.get() == first[0], "receiver and sender agree on resume point");
            check(sha(fac.out("huge.bin")).equals(sha(fs.f)), "file identical after resume");
        } finally { r2.stop(); }
    }

    public static void testWrongKey() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(key("ABCDEFGHJK"), fac, rec);
        try {
            FileSource fs = new FileSource(makeFile(src, "secret.txt", 100_000, 1));
            expectFail("wrong key", () -> send(portOf(r), key("ZZZZZZZZZZ"), Collections.singletonList((Source) fs)));
            check(rec.authFails.get() >= 1, "failed attempt counted");
            check(rec.started.get() == 0 && fac.out("secret.txt").length() == 0, "nothing stored for an unauthenticated peer");
            check(fac.out("secret.txt").exists() == false, "no file created");
            // a data connection with a wrong key must not be able to write either
            check(send(portOf(r), key("ABCDEFGHJK"), Collections.singletonList((Source) fs)).complete, "right key still works");
        } finally { r.stop(); }
    }

    public static void testLockout() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(key("ABCDEFGHJK"), fac, rec);
        try {
            FileSource fs = new FileSource(makeFile(src, "a.txt", 1000, 1));
            for (int i = 0; i < Protocol.MAX_AUTH_FAILURES; i++) {
                try { send(portOf(r), key("ZZZZZZZZZZ"), Collections.singletonList((Source) fs)); } catch (IOException ignored) {}
            }
            check(r.authFailures() >= Protocol.MAX_AUTH_FAILURES, "failures counted");
            expectFail("locked out after too many wrong attempts",
                    () -> send(portOf(r), key("ABCDEFGHJK"), Collections.singletonList((Source) fs)));
        } finally { r.stop(); }
    }

    public static void testInsufficientStorage() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            FileSource a = new FileSource(makeFile(src, "first.bin", 40 * MB, 1));
            FileSource b = new FileSource(makeFile(src, "second.bin", 40 * MB, 2));
            fac.free.set(Protocol.RESERVE_BYTES + 50 * MB);
            List<Source> both = new ArrayList<>(); both.add(a); both.add(b);
            Sender.Result res = send(portOf(r), key, both);
            check(!res.complete, "not complete: second file does not fit");
            check(res.blockedIds.size() == 1 && res.blockedIds.get(0).equals(b.id()), "second file reported as blocked");
            check(res.needMore == 30 * MB, "shortfall is exact: " + res.needMore);
            check(rec.blocked.get() == 1 && rec.need.get() == 30 * MB, "receiver reports the same shortfall");
            check(fac.out("first.bin").isFile() && sha(fac.out("first.bin")).equals(sha(a.f)), "first file received intact");
            check(!fac.out("second.bin").exists(), "second file not started");

            fac.free.set(Long.MAX_VALUE / 4);            // user freed space on the receiver
            Sender.Result again = send(portOf(r), key, both);
            check(again.complete && again.blockedIds.isEmpty(), "completes after space was freed");
            check(again.haveCount == 1, "first file was not sent twice");
            check(sha(fac.out("second.bin")).equals(sha(b.f)), "second file intact");
            check(!fac.out("first.bin (1)").exists(), "no duplicate copy of the first file");
        } finally { r.stop(); }
    }

    public static void testAlreadyHave() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            FileSource a = new FileSource(makeFile(src, "a.bin", 3 * MB, 1));
            FileSource b = new FileSource(makeFile(src, "b.bin", 3 * MB, 2));
            List<Source> both = new ArrayList<>(); both.add(a); both.add(b);
            check(send(portOf(r), key, both).complete, "first send");
            int startedBefore = rec.started.get();
            Sender.Result again = send(portOf(r), key, both);
            check(again.complete && again.haveCount == 2, "second send finds both files already there");
            check(rec.started.get() == startedBefore, "nothing sent again");
            check(fac.out("a.bin").delete(), "receiver deletes a.bin to free space");
            Sender.Result third = send(portOf(r), key, both);
            check(third.complete && third.haveCount == 1, "only the deleted file is sent again");
            check(sha(fac.out("a.bin")).equals(sha(a.f)), "re-sent file intact");
        } finally { r.stop(); }
    }

    public static void testPathTraversalName() throws Exception {
        File src = tmp("src"); File rxRoot = tmp("rx"); DirFactory fac = new DirFactory(rxRoot);
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            File real = makeFile(src, "payload.bin", 2000, 1);
            FileSource evil = new FileSource(real, "../../evil.txt");
            check(send(portOf(r), key, Collections.singletonList((Source) evil)).complete, "transfer works");
            check(fac.out("evil.txt").isFile(), "stored under the plain name");
            check(!new File(rxRoot.getParentFile(), "evil.txt").exists(), "nothing written outside the folder");
            check(!new File(rxRoot.getParentFile().getParentFile(), "evil.txt").exists(), "nothing written two levels up");
        } finally { r.stop(); }
    }

    public static void testMalformedInput() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            int port = portOf(r);
            // authenticated peer sends hostile headers: the connection must simply be closed
            check(hostileQuery(port, key, out -> out.writeInt(1_000_000)), "huge file count rejected");
            check(hostileQuery(port, key, out -> { out.writeInt(1); out.writeUTF("abc"); out.writeUTF("x"); out.writeLong(-5); }), "negative size rejected");
            check(hostileQuery(port, key, out -> { out.writeInt(1); out.writeUTF("../x"); out.writeUTF("x"); out.writeLong(5); }), "bad id rejected");
            check(hostileQuery(port, key, out -> { out.writeInt(1); out.writeUTF("abc"); out.writeUTF("x"); out.writeLong(Long.MAX_VALUE); }), "absurd size rejected");
            check(hostileData(port, key, "nope", 0, 1), "data for unknown file rejected");
            // unauthenticated garbage
            try (Socket s = new Socket("127.0.0.1", port)) {
                s.setSoTimeout(5000);
                OutputStream o = s.getOutputStream();
                o.write(new byte[200]); o.flush();
                InputStream in = s.getInputStream();
                int n = 0; int x;
                while ((x = in.read()) >= 0) n++;
                check(n <= 16, "only the nonce is ever sent to an unauthenticated peer (" + n + " bytes)");
            }
            // still alive and correct afterwards
            FileSource fs = new FileSource(makeFile(src, "ok.bin", 100_000, 3));
            check(send(port, key, Collections.singletonList((Source) fs)).complete, "receiver still serves valid transfers");
            check(sha(fac.out("ok.bin")).equals(sha(fs.f)), "valid file intact");
            // a valid data request for a chunk index outside the file
            check(hostileData(port, key, fs.id(), 99, 1), "out-of-range chunk rejected");
        } finally { r.stop(); }
    }

    interface Hostile { void write(DataOutputStream o) throws IOException; }

    static boolean hostileQuery(int port, byte[] key, Hostile h) throws Exception {
        try (Socket s = new Socket("127.0.0.1", port)) {
            s.setSoTimeout(5000);
            DataInputStream in = new DataInputStream(s.getInputStream());
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            byte[] nonce = new byte[16]; in.readFully(nonce);
            out.writeByte(Protocol.T_QUERY); out.write(Auth.mac(key, nonce, Protocol.T_QUERY));
            try { h.write(out); out.flush(); }
            catch (IOException e) { return true; }   // receiver already hung up on the hostile message
            try { return in.read() == -1; }          // closed without any answer
            catch (IOException e) { return true; }
        }
    }

    static boolean hostileData(int port, byte[] key, String id, int start, int count) throws Exception {
        try (Socket s = new Socket("127.0.0.1", port)) {
            s.setSoTimeout(5000);
            DataInputStream in = new DataInputStream(s.getInputStream());
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            byte[] nonce = new byte[16]; in.readFully(nonce);
            out.writeByte(Protocol.T_DATA); out.write(Auth.mac(key, nonce, Protocol.T_DATA));
            out.writeUTF(id); out.writeInt(start); out.writeInt(count); out.flush();
            return in.read() == -1;
        }
    }

    public static void testCancel() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); fac.slowMs = 10;
        Receiver r = rx(key, fac, rec);
        try {
            FileSource fs = new FileSource(makeFile(src, "c.bin", 60 * MB, 1));
            final AtomicBoolean cancel = new AtomicBoolean(false);
            long t0 = System.nanoTime();
            try {
                Sender.send("127.0.0.1", portOf(r), key, Collections.singletonList((Source) fs),
                        (d, t) -> { if (d > 10 * MB) cancel.set(true); }, cancel);
                throw new AssertionError("expected cancel");
            } catch (IOException expected) { /* ok */ }
            check((System.nanoTime() - t0) / 1e9 < 15, "cancel stops promptly");
            check(!fac.out("c.bin").exists(), "cancelled file not published");
        } finally { r.stop(); }
    }


    // ---------- security: simulated attacks ----------
    static byte[] queryBytes(String id, String name, long size) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.writeInt(1); o.writeUTF(id); o.writeUTF(name); o.writeLong(size);
        return bo.toByteArray();
    }

    /** Opens a connection, answers the challenge for {@code macType}, sends type byte {@code sendType} + payload. */
    static int rawExchange(int port, byte[] key, byte macType, byte sendType, byte[] payload, boolean closeOutput) throws Exception {
        try (Socket s = new Socket("127.0.0.1", port)) {
            s.setSoTimeout(4000);
            DataInputStream in = new DataInputStream(s.getInputStream());
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            byte[] nonce = new byte[16]; in.readFully(nonce);
            out.writeByte(sendType); out.write(Auth.mac(key, nonce, macType)); out.write(payload); out.flush();
            if (closeOutput) s.shutdownOutput();
            try { return in.read(); } catch (java.net.SocketTimeoutException e) { return -2; }
        }
    }

    public static void testReplayAndTypeConfusion() throws Exception {
        DirFactory fac = new DirFactory(tmp("rx")); byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            int port = portOf(r);
            byte[] captured;
            try (Socket s = new Socket("127.0.0.1", port)) {           // attacker records a valid answer to challenge #1
                s.setSoTimeout(4000);
                byte[] n1 = new byte[16]; new DataInputStream(s.getInputStream()).readFully(n1);
                captured = Auth.mac(key, n1, Protocol.T_QUERY);
            }
            try (Socket s = new Socket("127.0.0.1", port)) {           // ...and replays it on a new connection
                s.setSoTimeout(4000);
                DataInputStream in = new DataInputStream(s.getInputStream());
                in.readFully(new byte[16]);
                OutputStream o = s.getOutputStream();
                o.write(Protocol.T_QUERY); o.write(captured); o.write(queryBytes("abc", "x.bin", 10)); o.flush();
                check(in.read() == -1, "replayed answer is rejected");
            }
            // valid answer for QUERY presented as DATA (type confusion)
            check(rawExchange(port, key, Protocol.T_QUERY, Protocol.T_DATA, new byte[0], true) == -1, "type confusion rejected");
            check(rec.authFails.get() == 2, "both attacks counted: " + rec.authFails.get());
            check(rec.started.get() == 0, "nothing was stored");
        } finally { r.stop(); }
    }

    public static void testIdleAndConnectionFlood() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx")); byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            int port = portOf(r);
            // 1) a connection that never authenticates is dropped quickly (not held for 20 s)
            long t0 = System.nanoTime();
            try (Socket s = new Socket("127.0.0.1", port)) {
                s.setSoTimeout(9000);
                InputStream in = s.getInputStream();
                int got = 0, x;
                while ((x = in.read()) >= 0) got++;
                double sec = (System.nanoTime() - t0) / 1e9;
                check(got == 16, "only the 16-byte challenge is sent (" + got + ")");
                check(sec > 3 && sec < 8, "idle peer dropped after the pre-auth timeout: " + sec + "s");
            }
            // 2) flood: more idle connections than allowed -> extra ones are refused at once
            List<Socket> socks = new ArrayList<>();
            int extra = 10, closedAtOnce = 0;
            for (int i = 0; i < Protocol.MAX_CONNECTIONS + extra; i++) socks.add(new Socket("127.0.0.1", port));
            Thread.sleep(500);
            for (Socket s : socks) {
                s.setSoTimeout(700);
                try { if (s.getInputStream().read() == -1) closedAtOnce++; } catch (java.net.SocketTimeoutException e) { /* holds a slot */ }
                catch (IOException e) { closedAtOnce++; }
            }
            check(closedAtOnce >= extra - 1, "connections above the limit are refused (" + closedAtOnce + ")");
            for (Socket s : socks) s.close();
            Thread.sleep(800);
            // 3) and the receiver recovers and still serves real transfers
            FileSource fs = new FileSource(makeFile(src, "after-flood.bin", 200_000, 1));
            check(send(port, key, Collections.singletonList((Source) fs)).complete, "serves transfers after the flood");
            check(sha(fac.out("after-flood.bin")).equals(sha(fs.f)), "file intact after flood");
        } finally { r.stop(); }
    }

    public static void testMemoryExhaustionGuards() throws Exception {
        DirFactory fac = new DirFactory(tmp("rx")); byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            int port = portOf(r);
            long t0 = System.nanoTime();
            check(hostileQuery(port, key, out -> {                     // 2000 files x 4 TB each (would need ~250 MB of bitmaps)
                out.writeInt(2000);
                for (int i = 0; i < 2000; i++) { out.writeUTF("f" + i); out.writeUTF("x"); out.writeLong(1L << 42); }
            }), "absurd announcement rejected");
            check((System.nanoTime() - t0) / 1e9 < 3, "rejected quickly");
            check(hostileQuery(port, key, out -> { out.writeInt(2001); }), "more than the maximum file count rejected");
            check(rec.started.get() == 0 && fac.root.list().length == 2, "nothing created");
        } finally { r.stop(); }
    }

    public static void testFuzzReceiver() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx")); byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            int port = portOf(r);
            Random rnd = new Random(12345);
            byte[] valid = queryBytes("fuzzid", "fuzz.bin", 1000);
            int rounds = 400;
            for (int i = 0; i < rounds; i++) {
                byte type = (i % 2 == 0) ? Protocol.T_QUERY : Protocol.T_DATA;
                byte[] payload;
                if (i % 4 < 2) { payload = new byte[rnd.nextInt(300)]; rnd.nextBytes(payload); }          // pure noise
                else { payload = valid.clone(); for (int k = 0; k < 1 + rnd.nextInt(4); k++) payload[rnd.nextInt(payload.length)] ^= (byte) (1 + rnd.nextInt(255)); }  // mutated valid message
                rawExchange(port, key, type, type, payload, true);       // must never hang or crash the receiver
            }
            check(!fac.out("fuzz.bin").exists() || fac.out("fuzz.bin").length() == 1000, "no corrupt output file");
            String[] top = fac.root.list(); Arrays.sort(top);
            check(Arrays.equals(top, new String[]{"out", "part"}), "no stray files: " + Arrays.toString(top));
            FileSource fs = new FileSource(makeFile(src, "alive.bin", 300_000, 8));
            check(send(port, key, Collections.singletonList((Source) fs)).complete, "receiver survives " + rounds + " fuzz rounds");
            check(sha(fac.out("alive.bin")).equals(sha(fs.f)), "valid transfer intact after fuzzing");
        } finally { r.stop(); }
    }

    public static void testNameFuzz() {
        Random rnd = new Random(777);
        String specials = "/\\:*?\"<>|.. \u0000\n\t\u007f\u202e\u2028~$%";
        for (int i = 0; i < 40000; i++) {
            StringBuilder sb = new StringBuilder();
            int len = rnd.nextInt(i % 50 == 0 ? 600 : 40);
            for (int k = 0; k < len; k++) {
                int pick = rnd.nextInt(4);
                if (pick == 0) sb.append(specials.charAt(rnd.nextInt(specials.length())));
                else if (pick == 1) sb.appendCodePoint(0x20 + rnd.nextInt(0x2FFF));
                else sb.append((char) ('a' + rnd.nextInt(26)));
            }
            String out = Names.sanitize(sb.toString());
            check(out != null && !out.isEmpty() && out.length() <= Protocol.MAX_NAME, "length of '" + out + "'");
            check(out.indexOf('/') < 0 && out.indexOf('\\') < 0, "no separators in '" + out + "'");
            check(!out.equals(".") && !out.equals(".."), "not a dot name");
            check(!out.endsWith(".") && !out.endsWith(" "), "no trailing dot/space in '" + out + "'");
            for (int k = 0; k < out.length(); k++) { char c = out.charAt(k); check(c >= 0x20 && c != 0x7f, "no control char"); }
            check(Names.sanitize(out).equals(out), "idempotent: " + out);
        }
    }

    public static void testKeyQuality() throws Exception {
        Set<String> codes = new HashSet<>();
        int[] freq = new int[Keys.ALPHABET.length()];
        int N = 5000;
        for (int i = 0; i < N; i++) {
            String c = Keys.newCode(); check(Keys.isValid(c), "valid code"); codes.add(c);
            for (int k = 0; k < c.length(); k++) freq[Keys.ALPHABET.indexOf(c.charAt(k))]++;
        }
        check(codes.size() == N, "no duplicate codes in " + N);
        double expected = N * Keys.CODE_LEN / (double) freq.length, chi = 0;
        for (int f : freq) chi += (f - expected) * (f - expected) / expected;
        check(chi < 70, "characters are uniformly distributed (chi-square " + String.format("%.1f", chi) + ", 31 dof)");
        Keys a = Keys.derive("ABCDEFGHJK", 1000), b = Keys.derive("ABCDEFGHJL", 1000);
        int diff = 0;
        for (int i = 0; i < 32; i++) diff += Integer.bitCount((a.authKey[i] ^ b.authKey[i]) & 0xff);
        check(diff > 90 && diff < 166, "one changed character flips ~half of the key bits: " + diff + "/256");
        long t0 = System.nanoTime();
        Keys.derive("ABCDEFGHJK");                                        // real work factor
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("      info: one guess costs %.0f ms on this CPU core (50-bit code, 120,000 PBKDF2 rounds)%n", ms);
        check(ms > 5, "key derivation is deliberately slow");
    }

    public static void testManyFilesNeverOverCommitSpace() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx")); byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            List<Source> files = new ArrayList<>();
            for (int i = 0; i < 200; i++) files.add(new FileSource(makeFile(src, "f" + i + ".bin", 262144, 100 + i)));
            fac.free.set(Protocol.RESERVE_BYTES + 80L * 262144);      // room for exactly 80 files
            Sender.Result res = send(portOf(r), key, files);
            int stored = fac.out.list().length;
            check(!res.complete && res.blockedIds.size() == 120, "120 files blocked, got " + res.blockedIds.size());
            check(stored == 80, "exactly 80 files stored, got " + stored);
            check(res.needMore == 262144, "shortfall reported for the next file: " + res.needMore);
        } finally { r.stop(); }
    }

    public static void testConcurrentSenders() throws Exception {
        final DirFactory fac = new DirFactory(tmp("rx")); final byte[] key = key("ABCDEFGHJK");
        Rec rec = new Rec(); Receiver r = rx(key, fac, rec);
        try {
            final int port = portOf(r);
            final List<FileSource> all = Collections.synchronizedList(new ArrayList<FileSource>());
            List<Thread> th = new ArrayList<>(); final List<Throwable> errs = Collections.synchronizedList(new ArrayList<Throwable>());
            for (int t = 0; t < 4; t++) {
                final File src = tmp("src" + t); final int id = t;
                Thread x = new Thread(() -> {
                    try {
                        List<Source> files = new ArrayList<>();
                        for (int k = 0; k < 3; k++) { FileSource fs = new FileSource(makeFile(src, "s" + id + "-" + k + ".bin", (k + 1) * 3 * MB + id, id * 10 + k)); files.add(fs); all.add(fs); }
                        check(send(port, key, files).complete, "sender " + id + " complete");
                    } catch (Throwable e) { errs.add(e); }
                });
                th.add(x); x.start();
            }
            for (Thread x : th) x.join();
            check(errs.isEmpty(), "no errors: " + errs);
            for (FileSource fs : all) check(sha(fac.out(fs.name())).equals(sha(fs.f)), "intact " + fs.name());
        } finally { r.stop(); }
    }

    public static void testMaliciousReceiver() throws Exception {
        // a fake receiver answers with a gigantic bitmap length: the sender must refuse, not allocate
        final java.net.ServerSocket fake = new java.net.ServerSocket(0, 5, java.net.InetAddress.getLoopbackAddress());
        Thread th = new Thread(() -> {
            try (Socket s = fake.accept()) {
                s.getOutputStream().write(new byte[16]);
                s.getOutputStream().flush();
                Thread.sleep(300);
                byte[] junk = new byte[4096]; s.getInputStream().read(junk);
                DataOutputStream o = new DataOutputStream(s.getOutputStream());
                o.writeLong(0); o.writeInt(1); o.writeByte(0); o.writeLong(0); o.writeInt(1 << 30); o.flush();
                Thread.sleep(500);
            } catch (Exception ignored) {}
        });
        th.start();
        File src = tmp("src");
        FileSource fs = new FileSource(makeFile(src, "x.bin", 1000, 1));
        long t0 = System.nanoTime();
        expectFail("hostile reply", () -> Sender.send("127.0.0.1", fake.getLocalPort(), key("ABCDEFGHJK"),
                Collections.singletonList((Source) fs), (d, t) -> {}, new AtomicBoolean(false)));
        check((System.nanoTime() - t0) / 1e9 < 5, "refused quickly");
        th.join(); fake.close();
    }

    // ---------- runner ----------
    public static void main(String[] args) {
        String[] names = {"testNames", "testKeys", "testTransfer", "testResume", "testWrongKey", "testLockout",
                "testInsufficientStorage", "testAlreadyHave", "testPathTraversalName", "testMalformedInput", "testCancel",
                "testReplayAndTypeConfusion", "testIdleAndConnectionFlood", "testMemoryExhaustionGuards", "testFuzzReceiver",
                "testNameFuzz", "testKeyQuality", "testManyFilesNeverOverCommitSpace", "testConcurrentSenders", "testMaliciousReceiver"};
        int failed = 0;
        for (String n : names) {
            long t0 = System.nanoTime();
            try {
                CoreTests.class.getMethod(n).invoke(null);
                cleanup();
                System.out.printf("PASS  %-26s %5.1fs%n", n, (System.nanoTime() - t0) / 1e9);
            } catch (java.lang.reflect.InvocationTargetException e) {
                cleanup();
                failed++;
                System.out.printf("FAIL  %-26s %s%n", n, e.getCause());
                if (!(e.getCause() instanceof AssertionError)) e.getCause().printStackTrace(System.out);
            } catch (Exception e) { failed++; System.out.println("FAIL  " + n + " " + e); }
        }
        System.out.println(failed == 0 ? "ALL " + names.length + " TESTS PASSED" : failed + " TEST(S) FAILED");
        System.exit(failed == 0 ? 0 : 1);
    }
}
