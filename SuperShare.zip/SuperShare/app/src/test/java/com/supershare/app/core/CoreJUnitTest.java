package com.supershare.app.core;

import org.junit.After;
import org.junit.Test;

/** Runs the plain-JDK tests under Gradle / CI. */
public class CoreJUnitTest {
    @After public void tidy() { CoreTests.cleanup(); }
    @Test public void names() { CoreTests.testNames(); }
    @Test public void keys() throws Exception { CoreTests.testKeys(); }
    @Test public void transfer() throws Exception { CoreTests.testTransfer(); }
    @Test public void resume() throws Exception { CoreTests.testResume(); }
    @Test public void wrongKey() throws Exception { CoreTests.testWrongKey(); }
    @Test public void lockout() throws Exception { CoreTests.testLockout(); }
    @Test public void insufficientStorage() throws Exception { CoreTests.testInsufficientStorage(); }
    @Test public void alreadyHave() throws Exception { CoreTests.testAlreadyHave(); }
    @Test public void pathTraversalName() throws Exception { CoreTests.testPathTraversalName(); }
    @Test public void malformedInput() throws Exception { CoreTests.testMalformedInput(); }
    @Test public void cancel() throws Exception { CoreTests.testCancel(); }
    @Test public void replayAndTypeConfusion() throws Exception { CoreTests.testReplayAndTypeConfusion(); }
    @Test public void idleAndConnectionFlood() throws Exception { CoreTests.testIdleAndConnectionFlood(); }
    @Test public void memoryExhaustionGuards() throws Exception { CoreTests.testMemoryExhaustionGuards(); }
    @Test public void fuzzReceiver() throws Exception { CoreTests.testFuzzReceiver(); }
    @Test public void nameFuzz() throws Exception { CoreTests.testNameFuzz(); }
    @Test public void keyQuality() throws Exception { CoreTests.testKeyQuality(); }
    @Test public void manyFilesNeverOverCommitSpace() throws Exception { CoreTests.testManyFilesNeverOverCommitSpace(); }
    @Test public void concurrentSenders() throws Exception { CoreTests.testConcurrentSenders(); }
    @Test public void maliciousReceiver() throws Exception { CoreTests.testMaliciousReceiver(); }
}
