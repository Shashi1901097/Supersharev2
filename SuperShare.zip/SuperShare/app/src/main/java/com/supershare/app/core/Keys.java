package com.supershare.app.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * A pairing code has 10 characters from a 32-letter alphabet (50 bits of randomness).
 * From it we derive the Wi-Fi Direct network name and password and the key used to authenticate
 * every connection. The code is random per session, so it is useless once the session ends.
 */
public final class Keys {
    public static final String ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    public static final int CODE_LEN = 10;
    public static final int ITERATIONS = 120_000;
    private static final byte[] SALT = "SuperShare/v1/wifi+auth".getBytes(StandardCharsets.UTF_8);

    public final String wifiName;
    public final String wifiPass;
    public final byte[] authKey;

    private Keys(String wifiName, String wifiPass, byte[] authKey) {
        this.wifiName = wifiName;
        this.wifiPass = wifiPass;
        this.authKey = authKey;
    }

    public static String newCode() {
        SecureRandom r = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < CODE_LEN; i++) b.append(ALPHABET.charAt(r.nextInt(ALPHABET.length())));
        return b.toString();
    }

    /** Upper-cases and drops every character that cannot be part of a code (spaces, dashes, 0, 1, I, O). */
    public static String normalize(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < CODE_LEN; i++) {
            char u = Character.toUpperCase(s.charAt(i));
            if (ALPHABET.indexOf(u) >= 0) b.append(u);
        }
        return b.toString();
    }

    public static boolean isValid(String code) {
        if (code == null || code.length() != CODE_LEN) return false;
        for (int i = 0; i < code.length(); i++) if (ALPHABET.indexOf(code.charAt(i)) < 0) return false;
        return true;
    }

    public static String pretty(String code) {
        return code.length() > 5 ? code.substring(0, 5) + "-" + code.substring(5) : code;
    }

    public static Keys derive(String code) throws GeneralSecurityException {
        return derive(code, ITERATIONS);
    }

    public static Keys derive(String code, int iterations) throws GeneralSecurityException {
        if (!isValid(code)) throw new IllegalArgumentException("Invalid code");
        PBEKeySpec spec = new PBEKeySpec(code.toCharArray(), SALT, iterations, 52 * 8);
        byte[] k;
        try {
            k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
        return new Keys("DIRECT-SS-" + hex(k, 0, 4), hex(k, 4, 16), Arrays.copyOfRange(k, 20, 52));
    }

    private static String hex(byte[] b, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = off; i < off + len; i++) sb.append(String.format("%02x", b[i]));
        return sb.toString();
    }
}
