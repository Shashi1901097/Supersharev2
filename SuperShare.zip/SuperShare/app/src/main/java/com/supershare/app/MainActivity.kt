package com.supershare.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.app.RecoverableSecurityException
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.supershare.app.core.Keys
import com.supershare.app.core.Progress
import com.supershare.app.core.Receiver
import com.supershare.app.core.ReceiverEvents
import com.supershare.app.core.Sender
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

const val PORT = 8988

class UiState {
    var screen by mutableStateOf("home")
    var prev by mutableStateOf("home")
    var status by mutableStateOf("")
    var message by mutableStateOf("")
    var code by mutableStateOf("")
    var codeInput by mutableStateOf("")
    var files by mutableStateOf<List<Item>>(emptyList())
    var blocked by mutableStateOf<Set<String>>(emptySet())
    var current by mutableStateOf("")
    var active by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var mbps by mutableFloatStateOf(0f)
    var peak by mutableFloatStateOf(0f)
    var eta by mutableLongStateOf(-1L)
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    var free by mutableLongStateOf(0L)
    var spaceAlert by mutableStateOf("")
    var library by mutableStateOf<List<RFile>>(emptyList())
    var partials by mutableStateOf<List<Partial>>(emptyList())
    private var t0 = 0L
    private var base = 0L

    fun newBatch() { t0 = 0L; base = 0L; progress = 0f; mbps = 0f; eta = -1L }
    fun reset() {
        newBatch(); peak = 0f; status = ""; current = ""; active = false
        done = 0; total = 0; spaceAlert = ""; blocked = emptySet(); busy = false
    }
    fun update(d: Long, t: Long) {
        if (t0 == 0L) { t0 = System.nanoTime(); base = d }
        active = true; done = d; total = t
        progress = if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f
        val sec = (System.nanoTime() - t0) / 1e9
        if (sec > 0.3) {
            val bps = (d - base) / sec
            mbps = (bps * 8 / 1e6).toFloat()
            if (mbps > peak) peak = mbps
            eta = if (bps > 1) ((t - d) / bps).toLong() else -1L
        }
    }
}

class MainActivity : ComponentActivity() {
    private val ui = UiState()
    private lateinit var storage: AndroidStorage
    private var wd: WifiDirect? = null
    private var receiver: Receiver? = null
    private var keys: Keys? = null
    private var picked: List<Item> = emptyList()
    private val sending = AtomicBoolean(false)
    private val cancel = AtomicBoolean(false)
    private var lastHost: String? = null
    private var lastCode: String = ""
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        picked = resolveItems(this, uris)
        ui.files = picked
        ui.blocked = emptySet()
    }
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        storage = AndroidStorage(applicationContext)
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        )
        refresh()
        val actions = Actions(
            onReceive = { startReceive() },
            onSend = { stopAll(); ui.reset(); ui.files = picked; ui.prev = "home"; ui.screen = "send" },
            onPick = { picker.launch(arrayOf("*/*")) },
            onStartSend = { startSend() },
            onStop = { cancel.set(true) },
            onBack = { back() },
            onFiles = { refresh(); ui.prev = ui.screen; ui.screen = "files" },
            onOpen = { openFile(it) },
            onDelete = { deleteFile(it) },
            onDiscard = { Library.discard(this, it); refresh() },
            onStorageSettings = { openStorageSettings() },
            onRefresh = { refresh() }
        )
        setContent { SuperTheme { AppScreen(ui, actions) } }
    }

    private fun refresh() {
        ui.free = freeSpace(applicationContext)
        ui.library = Library.list(applicationContext)
        ui.partials = Library.partials(applicationContext)
    }

    private fun back() {
        if (ui.screen == "files") { ui.screen = ui.prev; return }
        stopAll(); ui.screen = "home"
    }

    /** Keep Wi-Fi at full performance and the CPU/screen awake while transferring. */
    private fun boost() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "SuperShare").apply { acquire() }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SuperShare:xfer").apply { acquire(60 * 60 * 1000L) }
        } catch (e: Exception) { }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------------- receiving ----------------
    private fun startReceive() {
        stopAll(); ui.reset(); ui.screen = "receive"; boost()
        val code = Keys.newCode()
        ui.code = Keys.pretty(code)
        ui.status = "Preparing a secure link…"
        refresh()
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    if (ui.screen != "receive" && ui.screen != "files") return@runOnUiThread
                    try {
                        keys = k
                        val rx = Receiver(k.authKey, storage, object : ReceiverEvents {
                            override fun onBatch(done: Long, total: Long, blocked: Int, maxNeedMore: Long, firstBlockedName: String) {
                                ui.newBatch()
                                ui.spaceAlert = if (blocked > 0)
                                    "Not enough storage for \"$firstBlockedName\"" +
                                        (if (blocked > 1) " and ${blocked - 1} more" else "") +
                                        ". Free up ${fmtSize(maxNeedMore)} to continue."
                                else ""
                                refresh()
                            }
                            override fun onProgress(done: Long, total: Long) { ui.update(done, total) }
                            override fun onFileStart(name: String) { ui.current = name }
                            override fun onFileDone(name: String) { ui.status = "Received: $name"; refresh() }
                            override fun onAuthFailed(totalFailures: Int) {
                                ui.status = "A device tried a wrong code ($totalFailures)"
                            }
                        })
                        rx.start(PORT, null)
                        receiver = rx
                        wd = WifiDirect(this, {}, { ui.status = it }).also { it.host(k) }
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    // ---------------- sending ----------------
    private fun startSend() {
        val code = Keys.normalize(ui.codeInput)
        if (picked.isEmpty()) { ui.status = "Choose the files to send first"; return }
        if (!Keys.isValid(code)) { ui.status = "Enter the receiver's 10-character code"; return }
        boost(); cancel.set(false)
        val k = keys
        val host = lastHost
        if (host != null && k != null && lastCode == code) { doSend(host, k); return }
        ui.status = "Connecting securely…"
        wd?.stop(); wd = null; sending.set(false)
        Thread {
            try {
                val kk = Keys.derive(code)
                keys = kk
                runOnUiThread {
                    val w = WifiDirect(this,
                        { info -> info.groupOwnerAddress?.hostAddress?.let { doSend(it, kk) } },
                        { ui.status = it })
                    wd = w
                    Handler(mainLooper).postDelayed({ w.join(kk) }, 700)
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun doSend(host: String, k: Keys) {
        if (!sending.compareAndSet(false, true)) return
        lastHost = host
        lastCode = Keys.normalize(ui.codeInput)
        cancel.set(false)
        val items = picked
        ui.busy = true
        Thread {
            val sources = items.map { AndroidSource(applicationContext, it) }
            var failures = 0
            var waited = 0L
            var failure: Exception? = null
            try {
                while (!cancel.get()) {
                    try {
                        ui.status = "Sending…"
                        val r = Sender.send(host, PORT, k.authKey, sources, Progress { d, t -> ui.update(d, t) }, cancel)
                        failures = 0
                        if (r.complete) {
                            ui.blocked = emptySet()
                            ui.status = "Done ✓ ${items.size} file(s)" +
                                (if (r.haveCount > 0) " (${r.haveCount} already on the receiver)" else "")
                            break
                        }
                        ui.blocked = r.blockedIds.toSet()
                        ui.status = "Receiver has insufficient storage. Waiting for ${fmtSize(r.needMore)} more space — " +
                            "it can delete files inside Super Share."
                        Thread.sleep(3000)
                        waited += 3000
                        if (waited > 15 * 60 * 1000L) { ui.status = "Stopped waiting for space. Tap Send to try again."; break }
                    } catch (e: IOException) {
                        if (cancel.get()) break
                        failures++
                        if (failures >= 4) throw e
                        ui.status = "Connection dropped, resuming… ($failures/4)"
                        Thread.sleep(2000)
                    }
                }
                if (cancel.get()) ui.status = "Stopped. Tap Send to continue where it stopped."
            } catch (e: Exception) {
                failure = e
            }
            val f = failure
            if (f != null) {
                lastHost = null     // the next tap re-joins the Wi-Fi link, then resumes from where it stopped
                ui.status = "Interrupted: ${f.message}. Tap Send to resume where it stopped."
            }
            ui.busy = false
            sending.set(false)
        }.start()
    }

    // ---------------- files ----------------
    private fun openFile(f: RFile) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, f.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: ActivityNotFoundException) {
            ui.message = "No app on this phone can open ${f.name}"
        }
    }

    private fun deleteFile(f: RFile) {
        try {
            contentResolver.delete(f.uri, null, null)
            refresh()
        } catch (e: SecurityException) {
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(f.uri))
                    deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else if (e is RecoverableSecurityException) {
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } else ui.message = "Could not delete ${f.name}"
            } catch (e2: Exception) { ui.message = "Could not delete ${f.name}" }
        }
    }

    private fun openStorageSettings() {
        try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { } }
    }

    private fun stopAll() {
        val r = receiver; receiver = null
        if (r != null) Thread { r.stop() }.start()       // stop() waits for saves, keep it off the UI thread
        wd?.stop(); wd = null
        lastHost = null; keys = null
        try { wifiLock?.release() } catch (e: Exception) { }
        wifiLock = null
        try { wakeLock?.release() } catch (e: Exception) { }
        wakeLock = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
