package com.supershare.app.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Receives files. Every connection must first answer a random challenge with HMAC(key, nonce),
 * all sizes/names/indexes from the peer are validated, files that do not fit into the free space are
 * refused (and reported), and progress is saved per 4 MB chunk so a transfer can resume.
 */
public final class Receiver {
    private static final class FileState {
        final String id, name;
        final long size;
        final int chunks;
        final BitSet bits;
        final Target target;
        final AtomicBoolean done = new AtomicBoolean(false);

        FileState(String id, String name, long size, BitSet bits, Target target) {
            this.id = id; this.name = name; this.size = size;
            this.chunks = Protocol.chunksOf(size);
            this.bits = bits; this.target = target;
        }
    }

    private final byte[] authKey;
    private final TargetFactory factory;
    private final ReceiverEvents ev;
    private final Map<String, FileState> states = new ConcurrentHashMap<>();
    private final Set<Socket> open = ConcurrentHashMap.newKeySet();
    private final AtomicLong batchDone = new AtomicLong();
    private volatile long batchTotal = 0;
    private final AtomicInteger authFailures = new AtomicInteger();
    private final Semaphore slots = new Semaphore(Protocol.MAX_CONNECTIONS);
    private final SecureRandom rnd = new SecureRandom();
    private ServerSocket server;
    private ExecutorService pool;

    public Receiver(byte[] authKey, TargetFactory factory, ReceiverEvents ev) {
        this.authKey = authKey.clone();
        this.factory = factory;
        this.ev = ev;
    }

    public int authFailures() { return authFailures.get(); }

    /** Starts listening. bind == null means all interfaces. Returns the port actually used. */
    public synchronized int start(int port, InetAddress bind) throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new java.net.InetSocketAddress(bind, port), 64);
        pool = Executors.newCachedThreadPool();
        final ServerSocket srv = server;
        pool.execute(() -> {
            while (!srv.isClosed()) {
                final Socket s;
                try { s = srv.accept(); } catch (IOException e) { break; }
                if (!slots.tryAcquire()) { closeQuietly(s); continue; }
                open.add(s);
                try {
                    pool.execute(() -> {
                        try { handle(s); }
                        catch (IOException | RuntimeException ignored) { /* peer dropped; progress is saved */ }
                        finally { open.remove(s); closeQuietly(s); slots.release(); }
                    });
                } catch (RuntimeException rejected) {
                    open.remove(s); closeQuietly(s); slots.release();
                }
            }
        });
        return server.getLocalPort();
    }

    public synchronized void stop() {
        if (server != null) { try { server.close(); } catch (IOException ignored) {} }
        for (Socket s : open) closeQuietly(s);
        if (pool != null) {
            pool.shutdownNow();
            try { pool.awaitTermination(3, java.util.concurrent.TimeUnit.SECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        for (FileState f : states.values()) { saveBits(f); f.target.close(); }   // progress is saved before we return
    }

    private static void closeQuietly(Socket s) { try { s.close(); } catch (IOException ignored) {} }

    private void handle(Socket s) throws IOException {
        s.setTcpNoDelay(true);
        s.setSoTimeout(Protocol.PRE_AUTH_TIMEOUT_MS);
        try { s.setReceiveBufferSize(8 << 20); } catch (java.net.SocketException ignored) {}
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));

        byte[] nonce = new byte[16];
        rnd.nextBytes(nonce);
        out.write(nonce);
        out.flush();

        byte type = in.readByte();
        byte[] mac = new byte[32];
        in.readFully(mac);
        if (authFailures.get() >= Protocol.MAX_AUTH_FAILURES) return;          // locked out
        if (!MessageDigest.isEqual(Auth.mac(authKey, nonce, type), mac)) {
            ev.onAuthFailed(authFailures.incrementAndGet());
            return;
        }
        s.setSoTimeout(Protocol.SERVER_TIMEOUT_MS);
        if (type == Protocol.T_QUERY) query(in, out);
        else if (type == Protocol.T_DATA) data(in, out);
    }

    private FileState openState(String id, String name, long size) throws IOException {
        synchronized (states) {
            FileState f = states.get(id);
            if (f != null) return f;
            Target t = factory.open(id, name, size);
            BitSet b = t.loadBits();
            if (b == null) b = new BitSet();
            f = new FileState(id, name, size, b, t);
            states.put(id, f);
            return f;
        }
    }

    private void query(DataInputStream in, DataOutputStream out) throws IOException {
        int n = in.readInt();
        if (n < 0 || n > Protocol.MAX_FILES) return;
        String[] ids = new String[n];
        String[] names = new String[n];
        long[] sizes = new long[n];
        Set<String> seen = new HashSet<>();
        long totalChunks = 0;
        for (int i = 0; i < n; i++) {
            ids[i] = in.readUTF();
            if (!Protocol.validId(ids[i]) || !seen.add(ids[i])) return;
            names[i] = Names.sanitize(in.readUTF());
            sizes[i] = in.readLong();
            if (sizes[i] < 0 || sizes[i] > Protocol.MAX_FILE_SIZE) return;
            totalChunks += Protocol.chunksOf(sizes[i]);
            if (totalChunks > Protocol.MAX_TOTAL_CHUNKS) return;       // memory-exhaustion guard
        }

        long free = factory.freeBytes();
        long budget = free - Protocol.RESERVE_BYTES;
        byte[] status = new byte[n];
        long[] need = new long[n];
        BitSet[] bits = new BitSet[n];
        long total = 0, done = 0;
        int blocked = 0;
        long maxNeed = 0;
        String firstBlocked = "";

        for (int i = 0; i < n; i++) {
            total += sizes[i];
            int chunks = Protocol.chunksOf(sizes[i]);
            if (factory.alreadyHave(ids[i], sizes[i])) {
                BitSet all = new BitSet();
                all.set(0, chunks);
                bits[i] = all;
                status[i] = Protocol.S_HAVE;
                done += sizes[i];
                continue;
            }
            FileState f = states.get(ids[i]);
            BitSet b;
            if (f != null) { synchronized (f.bits) { b = (BitSet) f.bits.clone(); } }
            else { BitSet p = factory.peekBits(ids[i], sizes[i]); b = (p == null) ? new BitSet() : p; }
            long have = Protocol.doneBytes(b, sizes[i]);
            long remaining = sizes[i] - have;

            if (remaining == 0 || remaining <= budget) {
                budget -= remaining;
                f = openState(ids[i], names[i], sizes[i]);
                synchronized (f.bits) { b = (BitSet) f.bits.clone(); }
                have = Protocol.doneBytes(b, sizes[i]);
                bits[i] = b;
                done += have;
                status[i] = Protocol.S_ACCEPT;
                if (f.chunks == 0 || b.get(0, f.chunks).cardinality() == f.chunks) finish(f);
            } else {
                bits[i] = b;
                done += have;
                status[i] = Protocol.S_NO_SPACE;
                need[i] = remaining - Math.max(budget, 0);
                blocked++;
                if (need[i] > maxNeed) maxNeed = need[i];
                if (firstBlocked.isEmpty()) firstBlocked = names[i];
            }
        }
        batchTotal = total;
        batchDone.set(done);
        ev.onBatch(done, total, blocked, maxNeed, firstBlocked);
        ev.onProgress(done, total);

        out.writeLong(free);
        out.writeInt(n);
        for (int i = 0; i < n; i++) {
            out.writeByte(status[i]);
            out.writeLong(need[i]);
            byte[] b = bits[i].toByteArray();
            out.writeInt(b.length);
            out.write(b);
        }
        out.flush();
    }

    private void data(DataInputStream in, DataOutputStream out) throws IOException {
        String id = in.readUTF();
        int start = in.readInt();
        int count = in.readInt();
        FileState f = states.get(id);
        if (f == null || f.done.get()) return;
        if (start < 0 || count <= 0 || start >= f.chunks || (long) start + count > f.chunks) return;

        long offset = (long) start * Protocol.CHUNK;
        long end = Math.min(offset + (long) count * Protocol.CHUNK, f.size);
        ev.onFileStart(f.name);
        byte[] buf = new byte[Protocol.READ_BUF];
        long pos = offset;
        int marked = start;
        long lastSave = System.nanoTime();
        boolean ok = false;
        try {
            while (pos < end) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, end - pos));
                if (n < 0) break;
                f.target.write(pos, ByteBuffer.wrap(buf, 0, n));
                pos += n;
                ev.onProgress(batchDone.addAndGet(n), batchTotal);
                int doneChunks = (pos >= f.size) ? f.chunks : (int) (pos / Protocol.CHUNK);
                while (marked < doneChunks) { synchronized (f.bits) { f.bits.set(marked); } marked++; }
                if (System.nanoTime() - lastSave > 2_000_000_000L) { saveBits(f); lastSave = System.nanoTime(); }
            }
            ok = pos >= end;
        } finally {
            saveBits(f);
            boolean all;
            synchronized (f.bits) { all = f.bits.get(0, f.chunks).cardinality() == f.chunks; }
            if (all) finish(f);
        }
        if (ok) { out.writeByte(1); out.flush(); }          // tells the sender this range is safely stored
    }

    private void saveBits(FileState f) {
        if (f.done.get()) return;
        BitSet c;
        synchronized (f.bits) { c = (BitSet) f.bits.clone(); }
        try { f.target.saveBits(c); } catch (RuntimeException ignored) {}
    }

    private void finish(FileState f) throws IOException {
        if (!f.done.compareAndSet(false, true)) return;
        states.remove(f.id);
        f.target.finish();
        ev.onFileDone(f.name);
    }
}
