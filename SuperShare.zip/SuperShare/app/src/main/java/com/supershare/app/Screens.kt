package com.supershare.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.supershare.app.core.Keys
import kotlinx.coroutines.delay

class Actions(
    val onReceive: () -> Unit,
    val onSend: () -> Unit,
    val onPick: () -> Unit,
    val onStartSend: () -> Unit,
    val onStop: () -> Unit,
    val onBack: () -> Unit,
    val onFiles: () -> Unit,
    val onOpen: (RFile) -> Unit,
    val onDelete: (RFile) -> Unit,
    val onDiscard: (Partial) -> Unit,
    val onStorageSettings: () -> Unit,
    val onRefresh: () -> Unit
)

@Composable
fun AppScreen(ui: UiState, act: Actions) {
    BackHandler(enabled = ui.screen != "home") { act.onBack() }
    LaunchedEffect(ui.screen) {
        while (ui.screen == "receive" || ui.screen == "files") { act.onRefresh(); delay(2000) }
    }
    LaunchedEffect(ui.message) {
        if (ui.message.isNotEmpty()) { delay(4000); ui.message = "" }
    }
    var confirm by remember { mutableStateOf<RFile?>(null) }
    val pending = confirm
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete file?") },
            text = { Text("\"${pending.name}\" (${fmtSize(pending.size)}) will be deleted from this phone.") },
            confirmButton = { TextButton(onClick = { act.onDelete(pending); confirm = null }) { Text("Delete", color = Pink) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }

    Backdrop {
        when (ui.screen) {
            "home" -> HomeScreen(act)
            "receive" -> ReceiveScreen(ui, act) { confirm = it }
            "files" -> FilesScreen(ui, act) { confirm = it }
            else -> SendScreen(ui, act)
        }
    }
}

@Composable
private fun ColumnScope.HomeScreen(act: Actions) {
    Spacer(Modifier.height(28.dp))
    Logo(150.dp)
    Spacer(Modifier.height(10.dp))
    Wordmark()
    Spacer(Modifier.height(6.dp))
    Text("Connecting Family And Friends Easily Together", color = Color.White.copy(alpha = 0.7f),
        fontSize = 14.sp, textAlign = TextAlign.Center)
    Spacer(Modifier.weight(1f))
    ActionCard("Send", "Pick files and enter the receiver's code", true,
        Brush.linearGradient(listOf(Violet, Color(0xFF9B6BFF))), act.onSend)
    Spacer(Modifier.height(14.dp))
    ActionCard("Receive", "Show my code and wait for files", false,
        Brush.linearGradient(listOf(Color(0xFF0A8FD6), Cyan)), act.onReceive)
    Spacer(Modifier.height(14.dp))
    GradButton("My received files", brush = Brush.horizontalGradient(listOf(Color(0xFF2B2B55), Color(0xFF3A3A78)))) { act.onFiles() }
    Spacer(Modifier.height(16.dp))
    Text("© 2026 by Shashikumar H G", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
}

@Composable
private fun ColumnScope.ReceiveScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    TopBar("Receive", act.onBack)
    if (!ui.active) {
        Spacer(Modifier.height(4.dp)); Radar(); Spacer(Modifier.height(6.dp))
        Text("Your code", color = Color.White.copy(alpha = 0.6f))
        Text(ui.code, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 3.sp)
        Text("Type this code on the sender's phone", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
    } else {
        Spacer(Modifier.height(4.dp)); Gauge(ui, 210.dp); Spacer(Modifier.height(10.dp)); Stats(ui)
        if (ui.current.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Receiving: ${ui.current}", color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("Free space on this phone: ${fmtSize(ui.free)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
    if (ui.spaceAlert.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
            Text("⚠ Insufficient storage", color = Pink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(4.dp))
            Text(ui.spaceAlert, color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallButton("Delete files here", Cyan) { act.onFiles() }
                SmallButton("Phone storage", Violet) { act.onStorageSettings() }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Text(ui.status, color = Cyan, textAlign = TextAlign.Center, fontSize = 13.sp)
    if (ui.message.isNotEmpty()) Text(ui.message, color = Pink, fontSize = 13.sp)
    Spacer(Modifier.height(6.dp))
    Text("Received files", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
        modifier = Modifier.align(Alignment.Start))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.library) { f -> ReceivedRow(f, act, askDelete) }
    }
}

@Composable
private fun ReceivedRow(f: RFile, act: Actions, askDelete: (RFile) -> Unit) {
    FileRow(f.name, fmtSize(f.size)) {
        SmallButton("Open", Cyan) { act.onOpen(f) }
        Spacer(Modifier.padding(horizontal = 3.dp))
        SmallButton("Delete", Pink) { askDelete(f) }
    }
}

@Composable
private fun ColumnScope.FilesScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    TopBar("My files", act.onBack)
    val used = ui.library.sumOf { it.size }
    Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
        Text("Super Share files: ${fmtSize(used)}", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Free space on this phone: ${fmtSize(ui.free)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
    }
    Spacer(Modifier.height(8.dp))
    GradButton("Open phone storage settings", brush = Brush.horizontalGradient(listOf(Color(0xFF2B2B55), Color(0xFF3A3A78)))) {
        act.onStorageSettings()
    }
    if (ui.message.isNotEmpty()) Text(ui.message, color = Pink, fontSize = 13.sp)
    Spacer(Modifier.height(8.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (ui.partials.isNotEmpty()) {
            item { Text("Unfinished transfers", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp) }
            items(ui.partials) { p ->
                FileRow(p.name, "${fmtSize(p.done)} of ${fmtSize(p.size)} received") {
                    SmallButton("Discard", Pink) { act.onDiscard(p) }
                }
            }
            item { Spacer(Modifier.height(10.dp)) }
        }
        item { Text("Received files", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp) }
        if (ui.library.isEmpty()) {
            item { Text("No received files yet.", color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(8.dp)) }
        }
        items(ui.library) { f -> ReceivedRow(f, act, askDelete) }
    }
}

@Composable
private fun ColumnScope.SendScreen(ui: UiState, act: Actions) {
    TopBar("Send", act.onBack)
    OutlinedTextField(
        value = ui.codeInput,
        onValueChange = { ui.codeInput = Keys.normalize(it) },
        label = { Text("Receiver's code (10 characters)") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(10.dp))
    GradButton("＋  Choose files", brush = Brush.horizontalGradient(listOf(Color(0xFF2B2B55), Color(0xFF3A3A78)))) { act.onPick() }
    if (ui.files.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text("${ui.files.size} file(s) · ${fmtSize(ui.files.sumOf { it.size })}",
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
    }
    Spacer(Modifier.height(6.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.files) { f ->
            FileRow(f.name, if (f.id in ui.blocked) "⚠ Waiting: receiver needs more storage" else fmtSize(f.size))
        }
    }
    if (ui.active) {
        Spacer(Modifier.height(6.dp)); Gauge(ui, 180.dp); Spacer(Modifier.height(6.dp)); Stats(ui)
    }
    Spacer(Modifier.height(6.dp))
    Text(ui.status, color = if (ui.status.startsWith("Done")) Green else Cyan,
        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, fontSize = 14.sp)
    Spacer(Modifier.height(8.dp))
    if (ui.busy) {
        GradButton("Stop", brush = Brush.horizontalGradient(listOf(Pink, Color(0xFFFF7A59)))) { act.onStop() }
    } else {
        GradButton("Send now", enabled = ui.files.isNotEmpty() && Keys.normalize(ui.codeInput).length == Keys.CODE_LEN) {
            act.onStartSend()
        }
    }
}
