package com.supershare.app.core;

import java.io.Closeable;
import java.nio.channels.FileChannel;

public interface Opened extends Closeable {
    FileChannel channel();
}
