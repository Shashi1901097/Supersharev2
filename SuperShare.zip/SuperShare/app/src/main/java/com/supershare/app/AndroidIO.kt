package com.supershare.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.supershare.app.core.Opened
import com.supershare.app.core.Protocol
import com.supershare.app.core.Source
import com.supershare.app.core.Target
import com.supershare.app.core.TargetFactory
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.BitSet

const val FOLDER = "Download/SuperShare"

/** A file the user picked to send. */
class Item(val uri: Uri, val name: String, val size: Long, val id: String)

fun resolveItems(ctx: Context, uris: List<Uri>): List<Item> = uris.mapNotNull { u ->
    ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
        if (!c.moveToFirst()) return@use null
        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        val si = c.getColumnIndex(OpenableColumns.SIZE)
        val li = c.getColumnIndex("last_modified")
        val name = (if (ni >= 0) c.getString(ni) else null)?.takeIf { it.isNotBlank() }
            ?: (u.lastPathSegment ?: "file").substringAfterLast('/')
        var size = if (si >= 0 && !c.isNull(si)) c.getLong(si) else 0L
        if (size <= 0L) size = try {
            ctx.contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: 0L
        } catch (e: Exception) { 0L }
        val lm = if (li >= 0 && !c.isNull(li)) c.getLong(li) else 0L
        Item(u, name, size, Protocol.fileId(name, size, lm))
    }
}

class AndroidSource(private val ctx: Context, private val item: Item) : Source {
    override fun id(): String = item.id
    override fun name(): String = item.name
    override fun size(): Long = item.size
    override fun open(): Opened {
        val pfd = ctx.contentResolver.openFileDescriptor(item.uri, "r")
            ?: throw IOException("Cannot open ${item.name}")
        val ch = FileInputStream(pfd.fileDescriptor).channel
        return object : Opened {
            override fun channel(): FileChannel = ch
            override fun close() {
                try { ch.close() } catch (e: Exception) { }
                try { pfd.close() } catch (e: Exception) { }
            }
        }
    }
}

/**
 * Stores received files in Downloads/SuperShare. Unfinished files stay hidden (IS_PENDING) and their
 * progress is saved in the app's private folder, so they can be resumed or discarded.
 */
class AndroidStorage(private val ctx: Context) : TargetFactory {
    private val resumeDir = File(ctx.filesDir, "resume").apply { mkdirs() }
    private val doneDir = File(ctx.filesDir, "done").apply { mkdirs() }

    override fun freeBytes(): Long = freeSpace(ctx)

    override fun alreadyHave(id: String, size: Long): Boolean {
        val f = File(doneDir, "$id.txt")
        if (!f.exists()) return false
        return try {
            val l = f.readLines()
            val ok = l[1].toLong() == size && exists(ctx, Uri.parse(l[0]))
            if (!ok) f.delete()
            ok
        } catch (e: Exception) { f.delete(); false }
    }

    override fun peekBits(id: String, size: Long): BitSet? = readMeta(id, size)?.bits

    override fun open(id: String, name: String, size: Long): Target {
        val meta = readMeta(id, size)
        val uri = meta?.uri ?: create(name)
        return AndroidTarget(ctx, id, name, size, uri, meta?.bits ?: BitSet(), resumeDir, doneDir)
    }

    private class Meta(val uri: Uri, val bits: BitSet)

    private fun readMeta(id: String, size: Long): Meta? {
        val m = File(resumeDir, "$id.txt")
        if (!m.exists()) return null
        return try {
            val l = m.readLines()
            val uri = Uri.parse(l[0])
            if (l[2].toLong() != size || !exists(ctx, uri)) throw IOException("stale")
            Meta(uri, parseBits(l.getOrElse(3) { "" }))
        } catch (e: Exception) { m.delete(); null }
    }

    private fun create(name: String): Uri {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, FOLDER)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            ?: throw IOException("Cannot create file in Downloads")
    }
}

fun parseBits(hex: String): BitSet {
    val bytes = ByteArray(hex.length / 2) { i -> hex.substring(2 * i, 2 * i + 2).toInt(16).toByte() }
    return BitSet.valueOf(bytes)
}

fun exists(ctx: Context, uri: Uri): Boolean = try {
    ctx.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
} catch (e: Exception) { false }

fun freeSpace(ctx: Context): Long = try {
    StatFs((ctx.getExternalFilesDir(null) ?: ctx.filesDir).path).availableBytes
} catch (e: Exception) { 0L }

class AndroidTarget(
    private val ctx: Context, private val id: String, private val name: String, private val size: Long,
    val uri: Uri, private val initial: BitSet, private val resumeDir: File, private val doneDir: File
) : Target {
    private val lock = Any()
    private var pfd: ParcelFileDescriptor? = null
    private var ch: FileChannel? = null
    @Volatile private var finished = false

    private fun channel(): FileChannel = synchronized(lock) {
        ch ?: run {
            val p = ctx.contentResolver.openFileDescriptor(uri, "rw") ?: throw IOException("Cannot write $name")
            pfd = p
            val c = FileOutputStream(p.fileDescriptor).channel
            ch = c
            c
        }
    }

    override fun loadBits(): BitSet = initial.clone() as BitSet

    override fun saveBits(bits: BitSet) {
        if (finished) return
        val hex = bits.toByteArray().joinToString("") { "%02x".format(it) }
        try {   // write-then-rename so a reader never sees half a file
            val tmp = File(resumeDir, "$id.tmp")
            tmp.writeText("$uri\n$name\n$size\n$hex")
            tmp.renameTo(File(resumeDir, "$id.txt"))
        } catch (e: Exception) { }
    }

    override fun write(pos: Long, src: ByteBuffer) {
        val c = channel()
        var p = pos
        while (src.hasRemaining()) p += c.write(src, p)
    }

    override fun finish() {
        synchronized(lock) {
            if (finished) return
            finished = true
            close()
            val v = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, v, null, null)
            File(resumeDir, "$id.txt").delete()
            try { File(doneDir, "$id.txt").writeText("$uri\n$size") } catch (e: Exception) { }
        }
    }

    override fun close() {
        synchronized(lock) {
            try { ch?.close() } catch (e: Exception) { }
            try { pfd?.close() } catch (e: Exception) { }
            ch = null; pfd = null
        }
    }
}
