package com.supershare.app.core;

import java.security.GeneralSecurityException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Challenge-response: the receiver sends a random nonce, the sender proves it knows the key. */
public final class Auth {
    private Auth() {}

    public static byte[] mac(byte[] key, byte[] nonce, byte type) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(key, "HmacSHA256"));
            m.update(nonce);
            m.update(type);
            return m.doFinal();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
