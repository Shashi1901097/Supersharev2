package com.supershare.app.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.BitSet;

/** Constants and small helpers shared by sender and receiver. Pure JDK, no Android classes. */
public final class Protocol {
    private Protocol() {}

    public static final int CHUNK = 4 << 20;                 // resume granularity: 4 MB
    public static final long SPLIT_ABOVE = 32L << 20;        // runs larger than this use parallel streams
    public static final int BIG_STREAMS = 8;
    public static final int MAX_THREADS = 12;

    public static final byte T_QUERY = 1;
    public static final byte T_DATA = 2;

    public static final byte S_ACCEPT = 0;
    public static final byte S_NO_SPACE = 1;
    public static final byte S_HAVE = 2;

    public static final int MAX_FILES = 2000;
    public static final long MAX_FILE_SIZE = 1L << 42;       // 4 TB
    public static final int MAX_NAME = 200;
    public static final int MAX_ID = 64;
    public static final int MAX_CONNECTIONS = 32;
    public static final int MAX_AUTH_FAILURES = 8;
    public static final long RESERVE_BYTES = 100L << 20;     // always leave 100 MB free on the receiver
    public static final int SERVER_TIMEOUT_MS = 20_000;          // after authentication
    public static final int PRE_AUTH_TIMEOUT_MS = 5_000;         // idle connections that never authenticate are dropped fast
    public static final int READ_BUF = 1 << 20;                  // per-connection read buffer (keeps memory small)
    public static final long MAX_TOTAL_CHUNKS = 2_000_000L;      // cap on what one announcement may claim (~8 TB)

    public static int chunksOf(long size) {
        return (int) ((size + CHUNK - 1) / CHUNK);
    }

    /** Bytes covered by the finished chunks in {@code bits} for a file of {@code size} bytes. */
    public static long doneBytes(BitSet bits, long size) {
        int chunks = chunksOf(size);
        long b = (long) bits.get(0, chunks).cardinality() * CHUNK;
        if (chunks > 0 && bits.get(chunks - 1)) b -= (long) CHUNK * chunks - size;
        return b;
    }

    /** Same file (name + size + modified time) always gets the same id, so a transfer can be resumed. */
    public static String fileId(String name, long size, long lastModified) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256")
                    .digest((name + "|" + size + "|" + lastModified).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++) sb.append(String.format("%02x", d[i]));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean validId(String id) {
        if (id == null || id.isEmpty() || id.length() > MAX_ID) return false;
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-' || c == '_';
            if (!ok) return false;
        }
        return true;
    }
}
