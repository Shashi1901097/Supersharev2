package com.supershare.app.core;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.BitSet;

/** Where one incoming file is written. Implemented by the Android layer (MediaStore) and by tests. */
public interface Target {
    /** Progress saved earlier (finished 4 MB chunks), or an empty set. */
    BitSet loadBits();

    void saveBits(BitSet bits);

    /** Positional write of ALL remaining bytes of src. Must be safe to call from several threads. */
    void write(long pos, ByteBuffer src) throws IOException;

    /** The file is complete: make it visible to the user and forget the resume data. */
    void finish() throws IOException;

    /** Release handles without finishing (keeps the partial file for a later resume). */
    void close();
}
