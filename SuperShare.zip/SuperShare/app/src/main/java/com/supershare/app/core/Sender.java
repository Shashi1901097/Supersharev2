package com.supershare.app.core;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Sends files. It first asks the receiver what it already has and whether the rest fits into its free
 * space, then sends only the missing 4 MB chunks over several parallel streams (zero-copy sendfile).
 */
public final class Sender {
    public static final long STALL_NANOS = 30_000_000_000L;

    public static final class Result {
        /** True when nothing is left to send (everything stored, or already there). */
        public final boolean complete;
        /** Ids of files the receiver has no room for. */
        public final List<String> blockedIds;
        public final int haveCount;
        public final long needMore;
        public final long receiverFree;

        Result(boolean complete, List<String> blockedIds, int haveCount, long needMore, long receiverFree) {
            this.complete = complete; this.blockedIds = blockedIds; this.haveCount = haveCount;
            this.needMore = needMore; this.receiverFree = receiverFree;
        }
    }

    private static final class Reply {
        long free;
        byte[] status;
        long[] need;
        BitSet[] bits;
    }

    private static final class Task {
        final Source src; final int start; final int count; final long bytes;
        Task(Source src, int start, int count) {
            this.src = src; this.start = start; this.count = count;
            this.bytes = Math.min((long) count * Protocol.CHUNK, src.size() - (long) start * Protocol.CHUNK);
        }
    }

    private Sender() {}

    public static Result send(String host, int port, byte[] authKey, List<? extends Source> files,
                              Progress progress, AtomicBoolean cancel) throws IOException {
        long total = 0;
        for (Source s : files) {
            if (s.size() < 0) throw new IOException("Bad file size: " + s.name());
            total += s.size();
        }
        Reply q = query(host, port, authKey, files);

        long already = 0;
        for (int i = 0; i < files.size(); i++) already += Protocol.doneBytes(q.bits[i], files.get(i).size());
        AtomicLong sent = new AtomicLong(already);
        progress.onProgress(already, total);

        List<Task> tasks = new ArrayList<>();
        List<String> blocked = new ArrayList<>();
        int have = 0;
        long needMore = 0;
        for (int i = 0; i < files.size(); i++) {
            Source f = files.get(i);
            if (q.status[i] == Protocol.S_NO_SPACE) {
                blocked.add(f.id());
                needMore = Math.max(needMore, q.need[i]);
                continue;
            }
            if (q.status[i] == Protocol.S_HAVE) { have++; continue; }
            int chunks = Protocol.chunksOf(f.size());
            BitSet bits = q.bits[i];
            int c = bits.nextClearBit(0);
            while (c < chunks) {
                int next = bits.nextSetBit(c);
                int e = (next < 0 || next > chunks) ? chunks : next;
                int runChunks = e - c;
                long runBytes = Math.min((long) runChunks * Protocol.CHUNK, f.size() - (long) c * Protocol.CHUNK);
                int pieces = runBytes > Protocol.SPLIT_ABOVE ? Math.min(Protocol.BIG_STREAMS, runChunks) : 1;
                int per = (runChunks + pieces - 1) / pieces;
                int x = c;
                while (x < e) { int k = Math.min(per, e - x); tasks.add(new Task(f, x, k)); x += k; }
                c = bits.nextClearBit(e);
            }
        }
        if (!tasks.isEmpty()) runTasks(host, port, authKey, tasks, total, sent, progress, cancel);
        return new Result(blocked.isEmpty(), blocked, have, needMore, q.free);
    }

    private static Reply query(String host, int port, byte[] key, List<? extends Source> files) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), 8000);
            s.setSoTimeout(15000);
            DataInputStream in = new DataInputStream(s.getInputStream());
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            byte[] nonce = new byte[16];
            try { in.readFully(nonce); }
            catch (EOFException e) { throw new IOException("Receiver is not available"); }
            out.writeByte(Protocol.T_QUERY);
            out.write(Auth.mac(key, nonce, Protocol.T_QUERY));
            out.writeInt(files.size());
            for (Source f : files) { out.writeUTF(f.id()); out.writeUTF(f.name()); out.writeLong(f.size()); }
            out.flush();
            Reply r = new Reply();
            try {
                r.free = in.readLong();
                int n = in.readInt();
                if (n != files.size()) throw new IOException("Unexpected reply from receiver");
                r.status = new byte[n]; r.need = new long[n]; r.bits = new BitSet[n];
                for (int i = 0; i < n; i++) {
                    r.status[i] = in.readByte();
                    r.need[i] = in.readLong();
                    int len = in.readInt();
                    if (len < 0 || len > (Protocol.MAX_FILE_SIZE / Protocol.CHUNK / 8) + 16) throw new IOException("Bad reply");
                    byte[] b = new byte[len];
                    in.readFully(b);
                    r.bits[i] = BitSet.valueOf(b);
                }
            } catch (EOFException e) {
                throw new IOException("Receiver rejected the connection (wrong code or too many attempts)");
            }
            return r;
        }
    }

    private static void runTasks(String host, int port, byte[] key, List<Task> tasks, long total, AtomicLong sent,
                                 Progress progress, AtomicBoolean cancel) throws IOException {
        Collections.sort(tasks, (a, b) -> Long.compare(b.bytes, a.bytes));
        final ExecutorService pool = Executors.newFixedThreadPool(Math.min(Protocol.MAX_THREADS, tasks.size()));
        final Set<Closeable> live = ConcurrentHashMap.newKeySet();
        final AtomicLong lastMove = new AtomicLong(System.nanoTime());
        final AtomicBoolean abort = new AtomicBoolean(false);
        final ScheduledExecutorService dog = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "sender-watchdog");
            t.setDaemon(true);
            return t;
        });
        dog.scheduleWithFixedDelay(() -> {
            if (cancel.get() || System.nanoTime() - lastMove.get() > STALL_NANOS) { abort.set(true); closeAll(live); }
        }, 1, 1, TimeUnit.SECONDS);
        try {
            List<Future<Void>> fs = new ArrayList<>();
            for (final Task t : tasks) {
                fs.add(pool.submit((Callable<Void>) () -> {
                    sendTask(host, port, key, t, total, sent, progress, lastMove, live, abort, cancel);
                    return null;
                }));
            }
            for (Future<Void> f : fs) {
                try { f.get(); }
                catch (ExecutionException e) {
                    abort.set(true); closeAll(live);
                    if (cancel.get()) throw new IOException("Cancelled");
                    Throwable c = e.getCause();
                    if (c instanceof IOException) throw (IOException) c;
                    throw new IOException(String.valueOf(c));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    abort.set(true); closeAll(live);
                    throw new IOException("Interrupted");
                }
            }
        } finally {
            dog.shutdownNow();
            pool.shutdownNow();
        }
    }

    private static void closeAll(Set<Closeable> live) {
        for (Closeable c : live) { try { c.close(); } catch (IOException ignored) {} }
    }

    private static void sendTask(String host, int port, byte[] key, Task t, long total, AtomicLong sent,
                                 Progress progress, AtomicLong lastMove, Set<Closeable> live,
                                 AtomicBoolean abort, AtomicBoolean cancel) throws IOException {
        try (Opened o = t.src.open(); SocketChannel sc = SocketChannel.open()) {
            live.add(sc);
            try {
                sc.socket().setTcpNoDelay(true);
                try { sc.socket().setSendBufferSize(8 << 20); } catch (java.net.SocketException ignored) {}
                sc.socket().connect(new InetSocketAddress(host, port), 8000);
                sc.socket().setSoTimeout(15000);
                DataInputStream in = new DataInputStream(sc.socket().getInputStream());
                byte[] nonce = new byte[16];
                try { in.readFully(nonce); } catch (EOFException e) { throw new IOException("Receiver is busy or refused"); }
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(sc.socket().getOutputStream()));
                out.writeByte(Protocol.T_DATA);
                out.write(Auth.mac(key, nonce, Protocol.T_DATA));
                out.writeUTF(t.src.id());
                out.writeInt(t.start);
                out.writeInt(t.count);
                out.flush();

                FileChannel fc = o.channel();
                long pos = (long) t.start * Protocol.CHUNK;
                long end = pos + t.bytes;
                while (pos < end) {
                    if (cancel.get() || abort.get()) throw new IOException("Cancelled");
                    long w = fc.transferTo(pos, Math.min(4L << 20, end - pos), sc);
                    if (w <= 0) throw new IOException("File ended early: " + t.src.name());
                    pos += w;
                    lastMove.set(System.nanoTime());
                    progress.onProgress(sent.addAndGet(w), total);
                }
                sc.socket().setSoTimeout(60000);
                int ack;
                try { ack = in.read(); } catch (java.net.SocketTimeoutException e) { throw new IOException("Receiver did not confirm"); }
                if (ack != 1) throw new IOException("Receiver did not confirm the data");
            } finally {
                live.remove(sc);
            }
        }
    }
}
