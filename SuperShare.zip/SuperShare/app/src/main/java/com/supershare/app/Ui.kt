package com.supershare.app

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg1 = Color(0xFF0A0A1F)
val Bg2 = Color(0xFF17123F)
val Violet = Color(0xFF7C4DFF)
val Cyan = Color(0xFF00D2FF)
val Pink = Color(0xFFFF4D9D)
val Green = Color(0xFF4ADE80)

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }
    return if (i == 0) "$b B" else "%.1f %s".format(v, u[i])
}

fun fmtEta(s: Long): String = when {
    s < 0 -> "—"
    s < 60 -> "${s}s"
    else -> "${s / 60}m ${s % 60}s"
}

@Composable
fun SuperTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Bg1, surface = Bg2), content = content)

fun Modifier.glass(): Modifier =
    this.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.07f))

@Composable
fun Logo(dim: Dp) {
    val t = rememberInfiniteTransition(label = "logo")
    val s by t.animateFloat(1f, 1.04f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Image(
        painter = painterResource(R.drawable.logo_ring),
        contentDescription = "Super Share logo",
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(dim).graphicsLayer { scaleX = s; scaleY = s }
    )
}

@Composable
fun Wordmark() {
    Row {
        Text("SUPER ", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text("SHARE", color = Color(0xFF00B8D9), fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
    }
}

@Composable
fun Backdrop(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2)))) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.width * 0.85f
            val c1 = Offset(this.size.width * 0.95f, this.size.height * 0.04f)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = 0.38f), Color.Transparent), c1, r), r, c1)
            val c2 = Offset(this.size.width * 0.05f, this.size.height * 0.96f)
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.26f), Color.Transparent), c2, r), r, c2)
        }
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
fun ActionCard(title: String, sub: String, up: Boolean, brush: Brush, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(brush)
        .clickable(onClick = onClick).padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(56.dp)) {
            drawCircle(Color.White.copy(alpha = 0.22f))
            val c = this.size.width / 2
            val h = this.size.width * 0.2f
            val y1 = if (up) c + h else c - h
            val y2 = if (up) c - h else c + h
            val st = 5.dp.toPx()
            val dir = if (up) 1f else -1f
            drawLine(Color.White, Offset(c, y1), Offset(c, y2), st, StrokeCap.Round)
            drawLine(Color.White, Offset(c, y2), Offset(c - h * 0.8f, y2 + dir * h * 0.8f), st, StrokeCap.Round)
            drawLine(Color.White, Offset(c, y2), Offset(c + h * 0.8f, y2 + dir * h * 0.8f), st, StrokeCap.Round)
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(sub, fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
        }
    }
}

@Composable
fun GradButton(text: String, enabled: Boolean = true,
               brush: Brush = Brush.horizontalGradient(listOf(Violet, Cyan)), onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(56.dp).alpha(if (enabled) 1f else 0.4f)
        .clip(RoundedCornerShape(18.dp)).background(brush).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun SmallButton(text: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.18f))
        .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Radar() {
    val t = rememberInfiniteTransition(label = "r")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "p")
    Canvas(Modifier.size(140.dp)) {
        for (k in 0..2) {
            val f = (p + k / 3f) % 1f
            drawCircle(Cyan.copy(alpha = 1f - f), radius = this.size.minDimension / 2 * f, style = Stroke(4f))
        }
        drawCircle(Brush.linearGradient(listOf(Violet, Cyan)), radius = 16.dp.toPx())
    }
}

@Composable
fun Gauge(ui: UiState, dim: Dp) {
    val prog by animateFloatAsState(ui.progress, tween(300), label = "prog")
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 20.dp.toPx()
            val arc = Size(this.size.width - sw, this.size.height - sw)
            val tl = Offset(sw / 2, sw / 2)
            drawArc(Color.White.copy(alpha = 0.08f), -90f, 360f, false, tl, arc,
                style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(listOf(Violet, Cyan, Violet)), -90f, 360f * prog, false, tl, arc,
                style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.0f".format(ui.mbps), fontSize = 50.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Mbps", fontSize = 15.sp, color = Cyan, fontWeight = FontWeight.Bold)
            Text("%.1f MB/s".format(ui.mbps / 8), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier) {
    Column(modifier.glass().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
        Text(label, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
    }
}

@Composable
fun Stats(ui: UiState) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Stat("Transferred", "${fmtSize(ui.done)} / ${fmtSize(ui.total)}", Modifier.weight(1.5f))
        Stat("Time left", fmtEta(ui.eta), Modifier.weight(1f))
        Stat("Peak", "%.0f Mbps".format(ui.peak), Modifier.weight(1.1f))
    }
}

@Composable
fun FileRow(name: String, sub: String, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        val ext = name.substringAfterLast('.', "").take(4).uppercase().ifEmpty { "FILE" }
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(Violet, Cyan))), contentAlignment = Alignment.Center) {
            Text(ext, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(sub, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        actions()
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onBack) { Text("‹ Back", color = Cyan, fontSize = 16.sp) }
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.width(72.dp))
    }
}
