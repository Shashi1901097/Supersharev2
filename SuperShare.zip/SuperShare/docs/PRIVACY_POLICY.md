# Privacy Policy – Super Share
Last updated: 2026

Super Share (by Shashikumar H G) sends files directly between two phones over a private Wi-Fi Direct connection.

- **We collect no personal data.** The app has no accounts, no analytics, no advertising and no servers.
- **Files** you send or receive travel only between the two phones and are stored only on the receiving phone
  (Downloads/SuperShare). They are never uploaded anywhere.
- **Permissions**: "Nearby devices" (Android 13+) or "Location" (Android 12 and older) are required by Android to use
  Wi-Fi Direct. The app does not read or store your location.
- **Deleting data**: delete received files inside the app or in your Files app; uninstalling the app removes its data.

Contact: <add your e-mail address here>
