# Publishing Super Share on Google Play

1. **Test first** on two or more real phones (Android 10+): small files, a 1 GB+ file, many files, interrupt Wi-Fi mid-transfer,
   fill the receiver's storage, Open/Delete buttons. Fix anything odd before publishing.
2. **Make the GitHub repository Private** (Settings > General > Danger zone > Change visibility) before adding signing keys.
3. **Create an upload key** (once, keep it safe forever – losing it is painful):
   `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   (needs Java on a computer, or use Android Studio > Build > Generate Signed Bundle).
4. In the repository: Settings > Secrets and variables > Actions, add `KEYSTORE_BASE64` (output of `base64 -w0 upload.jks`),
   `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
5. Add `docs/release.yml` as `.github/workflows/release.yml`, run it (Actions > Release AAB > Run workflow) and download
   `SuperShare.aab`. Play needs an **AAB**, not an APK.
6. Play Console: create the app, upload the AAB (turn on Play App Signing), then fill in:
   - Store listing: name **Super Share**, short description, full description, `store/icon_512.png`,
     `store/feature_graphic_1024x500.png`, 2+ phone screenshots.
   - Privacy policy URL: host `docs/PRIVACY_POLICY.md` (e.g. GitHub Pages) and add your e-mail.
   - Data safety: no data collected, no data shared.
   - App access: no login. Ads: none. Content rating questionnaire.
   - Permissions declaration: Nearby devices / Location are used only for Wi-Fi Direct device-to-device transfer.
7. Google requires new apps to target Android 16 (API 36) – this project already does. Check the Play Console for
   any testing requirements that apply to new personal developer accounts (for example closed testing) before production.
